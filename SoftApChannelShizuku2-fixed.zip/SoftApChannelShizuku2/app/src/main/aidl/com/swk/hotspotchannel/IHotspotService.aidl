package com.swk.hotspotchannel;

interface IHotspotService {
    String getInfo();
    String setChannel(int channel);
}
