package com.swk.hotspotchannel;

import android.os.IBinder;
import android.os.Process;
import android.util.SparseIntArray;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Runs as a Shizuku UserService under shell UID when Shizuku uses ADB. */
public class HotspotService extends IHotspotService.Stub {
    private static final String SHELL_PACKAGE = "com.android.shell";
    private static final String WIFI_SERVICE = "wifi";

    private Object wifi;
    private Class<?> wifiInterfaceClass;
    private Class<?> softApConfigClass;
    private Class<?> builderClass;
    private int band5g;

    private synchronized void init() throws Exception {
        if (wifi != null) return;

        Class<?> serviceManager = Class.forName("android.os.ServiceManager");
        Method getService = serviceManager.getDeclaredMethod("getService", String.class);
        IBinder binder = (IBinder) getService.invoke(null, WIFI_SERVICE);
        if (binder == null) throw new IllegalStateException("wifi service binder is null");

        wifiInterfaceClass = Class.forName("android.net.wifi.IWifiManager");
        Class<?> wifiStub = Class.forName("android.net.wifi.IWifiManager$Stub");
        Method asInterface = wifiStub.getDeclaredMethod("asInterface", IBinder.class);
        wifi = asInterface.invoke(null, binder);
        if (wifi == null) throw new IllegalStateException("IWifiManager proxy is null");

        softApConfigClass = Class.forName("android.net.wifi.SoftApConfiguration");
        builderClass = Class.forName("android.net.wifi.SoftApConfiguration$Builder");
        Field field = softApConfigClass.getDeclaredField("BAND_5GHZ");
        field.setAccessible(true);
        band5g = field.getInt(null);
    }

    private Object getConfig() throws Exception {
        init();
        Method method = wifiInterfaceClass.getMethod("getSoftApConfiguration");
        return method.invoke(wifi);
    }

    private String channelsToString(Object config) {
        try {
            Method getChannels = softApConfigClass.getMethod("getChannels");
            SparseIntArray channels = (SparseIntArray) getChannels.invoke(config);
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < channels.size(); i++) {
                if (i > 0) out.append(", ");
                out.append(channels.keyAt(i)).append("=").append(channels.valueAt(i));
            }
            return out.toString();
        } catch (Throwable ignored) {
            try {
                Method getChannel = softApConfigClass.getMethod("getChannel");
                return "legacy=" + getChannel.invoke(config);
            } catch (Throwable e) {
                return "unknown";
            }
        }
    }

    private String acsToString(Object config) {
        try {
            Method get = softApConfigClass.getMethod("getAllowedAcsChannels", int.class);
            int[] channels = (int[]) get.invoke(config, band5g);
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < channels.length; i++) {
                if (i > 0) out.append(",");
                out.append(channels[i]);
            }
            return "{" + out + "}";
        } catch (Throwable e) {
            return "unknown";
        }
    }

    @Override
    public String getInfo() {
        try {
            Object config = getConfig();
            StringBuilder out = new StringBuilder();
            out.append("SoftApConfiguration\n");
            out.append("service UID=").append(Process.myUid()).append(" package=").append(SHELL_PACKAGE).append("\n");
            out.append("channels={").append(channelsToString(config)).append("}\n");
            out.append("ACS5=").append(acsToString(config)).append("\n");
            out.append("config=").append(config);
            return out.toString();
        } catch (Throwable e) {
            return "ERROR: " + rootMessage(e);
        }
    }

    @Override
    public String setChannel(int channel) {
        try {
            if (channel != 0 && channel != 36 && channel != 40 && channel != 44 && channel != 48) {
                throw new IllegalArgumentException("Use 0, 36, 40, 44 or 48");
            }

            Object config = getConfig();
            Constructor<?> ctor = builderClass.getConstructor(softApConfigClass);
            Object builder = ctor.newInstance(config);

            if (channel == 0) {
                Method setBand = builderClass.getMethod("setBand", int.class);
                setBand.invoke(builder, band5g);
            } else {
                Method setChannel = builderClass.getMethod("setChannel", int.class, int.class);
                setChannel.invoke(builder, channel, band5g);
            }

            Method build = builderClass.getMethod("build");
            Object newConfig = build.invoke(builder);

            Method setConfig = wifiInterfaceClass.getMethod(
                    "setSoftApConfiguration", softApConfigClass, String.class);
            Object result = setConfig.invoke(wifi, newConfig, SHELL_PACKAGE);
            boolean ok = Boolean.TRUE.equals(result);

            String after = getInfo();
            return (ok ? "OK: saved channel=" + channel : "FAILED: setSoftApConfiguration returned false")
                    + "\n" + after
                    + "\n\nTurn hotspot OFF and ON once, then Read again.";
        } catch (Throwable e) {
            return "ERROR: " + rootMessage(e);
        }
    }

    private static String rootMessage(Throwable t) {
        Throwable x = t;
        while (x.getCause() != null && x.getCause() != x) x = x.getCause();
        return x.getClass().getSimpleName() + ": " + String.valueOf(x.getMessage());
    }
}
