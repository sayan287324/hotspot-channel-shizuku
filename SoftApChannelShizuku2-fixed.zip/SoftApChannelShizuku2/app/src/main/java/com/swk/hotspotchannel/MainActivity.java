package com.swk.hotspotchannel;

import android.app.Activity;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 1001;
    private IHotspotService service;
    private TextView status;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> runOnUiThread(() -> {
                if (requestCode == REQUEST_CODE && grantResult == PackageManager.PERMISSION_GRANTED) bindService();
                else showStatus("Shizuku permission not granted");
            });

    private final android.content.ServiceConnection serviceConnection =
            new android.content.ServiceConnection() {
                @Override public void onServiceConnected(ComponentName name, IBinder binder) {
                    service = IHotspotService.Stub.asInterface(binder);
                    showInfo();
                }
                @Override public void onServiceDisconnected(ComponentName name) {
                    service = null;
                    showStatus("Shizuku UserService disconnected");
                }
            };

    private Shizuku.UserServiceArgs userServiceArgs() {
        return new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), HotspotService.class.getName()))
                .daemon(false)
                .processNameSuffix("softap-channel")
                .debuggable(BuildConfig.DEBUG)
                .version(1);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        Shizuku.addRequestPermissionResultListener(permissionListener);

        if (!Shizuku.pingBinder()) {
            showStatus("Shizuku is not running");
            return;
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE);
        } else {
            bindService();
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);

        TextView title = new TextView(this);
        title.setText("SoftAP channel control");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Shizuku → shell UID → IWifiManager → SoftApConfiguration.\nNo root and no Hotspot Channel Setter. The saved config is changed; restart hotspot manually.");
        hint.setPadding(0, 18, 0, 18);
        root.addView(hint);

        Button read = new Button(this);
        read.setText("Read current configuration");
        read.setOnClickListener(v -> showInfo());
        root.addView(read);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        int[] channels = {36, 40, 44, 48};
        for (int ch : channels) {
            Button b = new Button(this);
            b.setText(String.valueOf(ch));
            b.setOnClickListener(v -> apply(ch));
            row.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(row);

        Button auto = new Button(this);
        auto.setText("Auto (0)");
        auto.setOnClickListener(v -> apply(0));
        root.addView(auto);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextIsSelectable(true);
        status.setPadding(0, 22, 0, 0);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void bindService() {
        try {
            Shizuku.bindUserService(userServiceArgs(), serviceConnection);
            showStatus("Binding Shizuku UserService…");
        } catch (Throwable e) {
            showStatus("Bind error: " + e);
        }
    }

    private void showInfo() {
        if (service == null) {
            showStatus("Service not connected");
            return;
        }
        new Thread(() -> {
            try {
                String result = service.getInfo();
                runOnUiThread(() -> showStatus(result));
            } catch (RemoteException e) {
                runOnUiThread(() -> showStatus("Remote error: " + e));
            }
        }).start();
    }

    private void apply(int channel) {
        if (service == null) {
            Toast.makeText(this, "Shizuku service is not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(() -> {
            try {
                String result = service.setChannel(channel);
                runOnUiThread(() -> {
                    showStatus(result);
                    Toast.makeText(this, "Configuration saved", Toast.LENGTH_SHORT).show();
                });
            } catch (RemoteException e) {
                runOnUiThread(() -> showStatus("Remote error: " + e));
            }
        }).start();
    }

    private void showStatus(String text) {
        if (status != null) status.setText(text);
    }

    @Override protected void onDestroy() {
        try { Shizuku.unbindUserService(userServiceArgs(), serviceConnection, true); } catch (Throwable ignored) {}
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }
}
